package com.example.assignment3;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class MainActivity extends AppCompatActivity {

    TextView working_view;
    TextView result_view;
    String workings = "";
    String equation = "";
    String tempEquation = "";
    Button delete_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#607D8B"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        delete_button = (Button) findViewById(R.id.del_button);
        initTextViews();
    }

    private void initTextViews() {
        working_view = (TextView)findViewById(R.id.calculation);
        result_view = (TextView)findViewById(R.id.total);
    }

    private void setWorkings(String entered_value) {
        workings = workings + entered_value;
        working_view.setText(workings);
    }

    public void equalOnClick(View view) {
        Double result = null;
        javax.script.ScriptEngine engine = new ScriptEngineManager().getEngineByName("rhino");
        checkForPowerOf();

        try {
            result = (double)engine.eval(equation);
        } catch (ScriptException e) {
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
        }

        if(result != null)
            result_view.setText(String.valueOf(result.doubleValue()));
        else
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
    }

    private void checkForPowerOf() {
        ArrayList<Integer> indexOfPowers = new ArrayList<>();
        for(int i = 0; i < workings.length(); i++) {
            if (workings.charAt(i) == '^')
                indexOfPowers.add(i);
        }

        equation = workings;
        tempEquation = workings;
        for(Integer index: indexOfPowers) {
            changeEquation(index);
        }
        equation = tempEquation;
    }

    private void changeEquation(Integer index) {
        String left_number = "";
        String right_number = "";

        for(int i = index + 1; i< workings.length(); i++) {
            if(isNumeric(workings.charAt(i)))
                right_number = right_number + workings.charAt(i);
            else
                break;
        }

        for(int i = index - 1; i >= 0; i--) {
            if(isNumeric(workings.charAt(i)))
                left_number = left_number + workings.charAt(i);
            else
                break;
        }
    }

    private boolean isNumeric(char c) {
        if((c <= '9' && c >= '0') || c == '.')
            return true;
        return false;
    }

    public void delOnClick(View view) {
        working_view.setText("");
        workings = "";
        result_view.setText("");
//        if (result_view==null && working_view!=null) {
//            //delete number one at a time
//            String str = working_view.getText().toString();
//            if(!str.equals(""))
//                str = str.substring(0, str.length() - 1);
//            working_view.setText(str);
//        } else if (result_view!=null && working_view!=null) {
//            //delete everything at once
//            working_view.setText("");
//            workings = "";
//            result_view.setText("");
//        }
    }

    public void openBracketOnClick(View view) {
        setWorkings("(");
    }

    public void closeBracketOnClick(View view) {
        setWorkings(")");
    }

    public void oneOnClick(View view) {
        setWorkings("1");
    }

    public void twoOnClick(View view) {
        setWorkings("2");
    }

    public void threeOnClick(View view) {
        setWorkings("3");
    }

    public void fourOnClick(View view) {
        setWorkings("4");
    }

    public void fiveOnClick(View view) {
        setWorkings("5");
    }

    public void sixOnClick(View view) {
        setWorkings("6");
    }

    public void sevenOnClick(View view) {
        setWorkings("7");
    }

    public void eightOnClick(View view) {
        setWorkings("8");
    }

    public void nineOnClick(View view) {
        setWorkings("9");
    }

    public void zeroOnClick(View view) {
        setWorkings("0");
    }

    public void plusOnClick(View view) {
        setWorkings("+");
    }

    public void minusOnClick(View view) {
        setWorkings("-");
    }

    public void multiplyOnClick(View view) {
        setWorkings("*");
    }

    public void divideOnClick(View view) {
        setWorkings("/");
    }

    public void dotOnClick(View view) {
        setWorkings(".");
    }
}