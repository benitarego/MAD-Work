package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    WebView webView;

    String lTitle[] = {"Alpha", "Petit Four", "Cupcake", "Donut", "Eclair", "Froyo", "Gingerbread", "Honeycomb", "Ice Cream Sandwich"};

    String lSubtitle[] = {"API 1", "API 2", "API 3", "API 4", "API 5-7", "API 8", "API 9-10", "API 11-13", "API 14-15"};

    int images[] = {R.drawable.alpha, R.drawable.petitfour, R.drawable.cupcake, R.drawable.donut, R.drawable.eclair, R.drawable.froyo, R.drawable.gingerbread, R.drawable.honeycomb, R.drawable.icecreamsandwich};

    String[] urls = { "https://en.wikipedia.org/wiki/Android_version_history#Android_1.0",
            "https://en.wikipedia.org/wiki/Android_version_history#Android_1.1",
            "https://en.wikipedia.org/wiki/Android_Cupcake",
            "https://en.wikipedia.org/wiki/Android_Donut",
            "https://en.wikipedia.org/wiki/Android_Eclair",
            "https://en.wikipedia.org/wiki/Android_Froyo",
            "https://en.wikipedia.org/wiki/Android_Gingerbread",
            "https://en.wikipedia.org/wiki/Android_Honeycomb",
            "https://en.wikipedia.org/wiki/Android_Ice_Cream_Sandwich"
    };

    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        getSupportActionBar().setTitle("AndroidVersions");

        listView = findViewById(R.id.listview);
        webView = findViewById(R.id.webview);

        recyclerView = findViewById(R.id.recyclerview1);

        MyAdapter adapter = new MyAdapter(this, lTitle, lSubtitle, images);
        listView.setAdapter(adapter);
        listView.getSelectedItem();


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0) {
                    WebView webView = new WebView(view.getContext());
                    String[] urls = getResources().getStringArray(R.array.listview_urls);
                    webView.loadUrl(urls[position]);
                    Intent intent = new Intent(MainActivity.this ,WebViewActivity.class);
                    startActivity(intent);
                }
                else if(position == 1) {

                    Toast.makeText(MainActivity.this, "Alpha", Toast.LENGTH_SHORT).show();
                }
                else if(position == 2) {
                    Intent intent = new Intent(MainActivity.this ,WebViewActivity.class);
                    startActivity(intent);
                }
                else if(position == 3) {
                    Toast.makeText(MainActivity.this, "Donut", Toast.LENGTH_SHORT).show();
                }
                else if(position == 4) {
                    Toast.makeText(MainActivity.this, "Eclair", Toast.LENGTH_SHORT).show();
                }
                else if(position == 5) {
                    Toast.makeText(MainActivity.this, "Froyo", Toast.LENGTH_SHORT).show();
                }
                else if(position == 6) {
                    Toast.makeText(MainActivity.this, "Alpha", Toast.LENGTH_SHORT).show();
                }
                else if(position == 7) {
                    Toast.makeText(MainActivity.this, "Alpha", Toast.LENGTH_SHORT).show();
                }
                else if(position == 8) {
                    Toast.makeText(MainActivity.this, "Alpha", Toast.LENGTH_SHORT).show();
                }

//                WebView webView = new WebView(view.getContext());
//                String[] urls = getResources().getStringArray(R.array.listview_urls);
//                webView.loadUrl(urls[position]);
//                Intent intent = new Intent(MainActivity.this ,WebViewActivity.class);
//                startActivity(intent);
            }
        });
    }

    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        String lTitle[];
        String lSubtitle[];
        int lImages[];

        public MyAdapter (Context c, String title[], String subtitle[], int images[]) {
            super(c, R.layout.listview, R.id.ltitle, title);
            this.context = c;
            this.lTitle = title;
            this.lSubtitle = subtitle;
            this.lImages = images;
        }

        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View listView1 = layoutInflater.inflate(R.layout.listview, parent, false);
            ImageView images = listView1.findViewById(R.id.image);
            TextView myTitle = listView1.findViewById(R.id.ltitle);
            TextView myDescription = listView1.findViewById(R.id.lsubtitle);

            // now set our resources on views
            images.setImageResource(lImages[position]);
            myTitle.setText(lTitle[position]);
            myDescription.setText(lSubtitle[position]);

            return listView1;
        }
    }
}