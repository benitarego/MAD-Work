package com.example.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class WebViewActivity extends AppCompatActivity {

    String[] urls = {"Android_version_history#Android_1.0",
            "Android_version_history#Android_1.1",
            "Android_Cupcake",
            "Android_Donut",
            "Android_Eclair",
            "Android_Froyo",
            "Android_Gingerbread",
            "Android_Honeycomb",
            "Android_Ice_Cream_Sandwich"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("AndroidVersions");

        WebView webview = findViewById(R.id.webview);
        Bundle extras = getIntent().getExtras();

        for(int i=0; i < urls.length; i++) {
            String url = "https://en.wikipedia.org/wiki/" +extras.getString("urls");
            webview.loadUrl(url);
            webview.getSettings().setJavaScriptEnabled(true);
            webview.setWebViewClient(new WebViewClient());
        }
    }
}

