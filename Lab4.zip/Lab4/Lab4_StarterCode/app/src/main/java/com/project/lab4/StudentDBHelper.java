package com.project.lab4;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class StudentDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "students.db";
    private static final int DATABASE_VERSION = 2;

    private static final String CREATE_TABLE = "CREATE TABLE " +
            Student.Students.TABLE_NAME + "(" +
            Student.Students._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            Student.Students.STUDENT_ID + " TEXT NOT NULL, " +
            Student.Students.STUDENT_NAME + " TEXT NOT NULL, " +
            Student.Students.STUDENT_EMAIL + " TEXT" + ")";

    private static final String DROP_TABLE = "DROP TABLE IF EXISTS " + Student.Students.TABLE_NAME;

    public StudentDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop current table
        db.execSQL(DROP_TABLE);
        // create new table
        onCreate(db);
    }
}
