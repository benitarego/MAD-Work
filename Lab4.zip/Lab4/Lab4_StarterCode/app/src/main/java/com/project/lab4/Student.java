package com.project.lab4;

import android.provider.BaseColumns;

public final class Student {
    private Student() {

    }

    public static class Students implements BaseColumns {
        public static final String TABLE_NAME = "students_info";
        public static final String STUDENT_ID = "student_id";
        public static final String STUDENT_NAME = "name";
        public static final String STUDENT_EMAIL = "email";
    }
}
