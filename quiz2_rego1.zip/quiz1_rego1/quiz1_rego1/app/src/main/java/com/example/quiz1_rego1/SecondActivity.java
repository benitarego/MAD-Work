package com.example.quiz1_rego1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.DialogInterface;

public class SecondActivity extends AppCompatActivity implements  View.OnClickListener{

    TextView question_text;
    TextView question_full;
    Button option_one;
    Button option_two;
    Button option_three;
    Button option_four;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        question_text = findViewById(R.id.question);
        question_full = findViewById(R.id.questionfull);

        option_one = findViewById(R.id.option1);
        option_two = findViewById(R.id.option2);
        option_three = findViewById(R.id.option3);
        option_four = findViewById(R.id.option4);

        option_one.setOnClickListener(this);
        option_two.setOnClickListener(this);
        option_three.setOnClickListener(this);
        option_four.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.option1:
                onBackPressed();
                break;

            case R.id.option2:
                onBackPressed();
                break;
            case R.id.option3:
                Intent i = new Intent(this, ThirdActivity.class);
                startActivity(i);
                break;
            case R.id.option4:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(SecondActivity.this);
        builder.setMessage("Do you want to try again?");

        builder.setTitle("Answer is incorrect!");
        builder.setCancelable(false);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent i = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        AlertDialog alertDialog = builder.create();

        alertDialog.show();
    }

}